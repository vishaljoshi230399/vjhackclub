VJHackClub fixed website package

FIXES INCLUDED
- Replaced broken JPG image references with a locally included SVG illustration.
- Included local logo and favicon SVG files.
- Improved mobile spacing and responsive navigation layout.
- Kept the VJHackClub neon-green / dark theme and existing section structure.

PUBLISH ON GITHUB PAGES
1. Download and extract this ZIP.
2. Back up your current repository files.
3. Upload/replace index.html, style.css, script.js and the assets folder at the repository root.
4. Make sure index.html is at the repository root, not inside an extra nested folder.
5. Commit changes and wait for GitHub Pages to deploy.
6. Refresh https://vishaljoshi230399.github.io/vjhackclub/ (try a private tab if the old version is cached).

Note: The contact information and section content are retained from the current public website. Review them before publishing if needed.
