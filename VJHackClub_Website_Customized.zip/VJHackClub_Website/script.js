const toggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');
toggle.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  toggle.setAttribute('aria-expanded', String(open));
});
document.querySelectorAll('.nav a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open'); toggle.setAttribute('aria-expanded', 'false');
}));
document.getElementById('year').textContent = new Date().getFullYear();
document.getElementById('contact-form').addEventListener('submit', event => {
  event.preventDefault();
  const data = new FormData(event.currentTarget);
  const subject = encodeURIComponent('VJHackClub project enquiry — ' + data.get('service'));
  const body = encodeURIComponent(
    'Name: ' + data.get('name') + '\\nContact: ' + data.get('contact') +
    '\\nService: ' + data.get('service') + '\\nProject details: ' + (data.get('details') || 'Not provided')
  );
  // Enquiry drafts open in the visitor's email app; no data is sent automatically.
  window.location.href = 'mailto:Vjhackclub@gmail.com?subject=' + subject + '&body=' + body;
});